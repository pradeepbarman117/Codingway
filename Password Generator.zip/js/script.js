
// script for password Range 

const showRange = document.querySelector("#showRange");
const rangePass = document.querySelector("#rangePass");

rangePass.addEventListener("input",()=>{
  showRange.innerHTML= `${rangePass.value}`;
});

const upperInput = document.querySelector("#upperCase");
const lowerInput = document.querySelector("#lowerCase");
const numberInput = document.querySelector("#numbers");
const symbolInput = document.querySelector("#symbols");

const upperLatter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const lowerLetter = "abcdefghijklmnopqrstuvwxyz";
const NumberSet = "0123456789";
const symbolSet = "~!@#$%^&*()_+";


// script for Generate Botton

const genBtn = document.querySelector("#genBtn");


genBtn.addEventListener("click",()=>{

 	let dataSet = "";
	let password ="";	

 	if(upperInput.checked){
 		dataSet +=`${upperLatter}`;
 	}
 	if(lowerInput.checked){
 		dataSet +=`${lowerLetter}`;
 	}
 	if(numberInput.checked){
 		dataSet +=`${NumberSet}`;
 	}
 	if(symbolInput.checked){
 		dataSet +=`${symbolSet}`;
 	}
	
	for(let i=0;i<rangePass.value;i++){
		let getRandomData = Math.floor(Math.random()*dataSet.length)
		password += `${dataSet.charAt(getRandomData)}`;
	}
	 document.getElementById("displayInput").value = `${password}`;
	
	
});


// script for copy password

let copyBtn = document.querySelector("#copyBtn");
let copyText = document.querySelector("#displayInput");

copyBtn.addEventListener("click",()=>{
	copyInput();
	

});


function copyInput(){
	copyText.select();
	document.execCommand("copy")
}




