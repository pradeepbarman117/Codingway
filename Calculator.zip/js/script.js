let buttonGroup = document.querySelectorAll('.btn');
let clrGreen = document.querySelectorAll(".clr")

// for (let i = 0; i < buttonGroup.length; i++) {
    // buttonGroup[i].addEventListener("click", () => {
        // buttonGroup[i].classList.add("activeColor");
    // });
    // setInterval(() => {
        // buttonGroup[i].classList.remove('activeColor');
    // }, 200);
    // for (let i = 0; i < clrGreen.length; i++) {
        // clrGreen[i].addEventListener("clikc", () => {
            // clrGreen[i].classList.add("activeGreen");
        // });
        // setInterval(() => {
            // clrGreen[i].classList.remove("activeGreen");
        // }, 100);
    // }
// }

// script for Result 

let showInputTexts = document.querySelector("#showInputText");
let btnGroup = document.querySelectorAll('#btnText');

for (let p = 0; p < btnGroup.length; p++) {
    btnGroup[p].addEventListener("click", () => {
        showInputTexts.innerText += btnGroup[p].value;
    });
}

// operators

let operaTor = document.querySelectorAll("#operator");

for (let o = 0; o < operaTor.length; o++) {
    operaTor[o].addEventListener("click", () => {
        showInputTexts.innerText += `${operaTor[o].value}`;
    });
}

// clear Fuction

let Clear = document.querySelector("#clear");
Clear.addEventListener("click", () => {
    showInputTexts.innerText = ``;
});

// is Equal

let equalFun = document.getElementById("equal");

equalFun.addEventListener("click", () => {
    let x = eval(showInputTexts.innerText);
    showInputTexts.innerText = x;
});





