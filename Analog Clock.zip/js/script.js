
let hr_hour = document.querySelector("#hr");
let minute = document.querySelector("#min");
let second = document.querySelector("#sec");
setInterval(()=>{

let date = new Date();
	hour = date.getHours();
	min = date.getMinutes();
	sec = date.getSeconds();

	hour_rotation = 30 * hour + min / 2;
	min_rotation = 6 * min;
	sec_rotation = 6 * sec;

	hr_hour.style.transform = `rotate(${hour_rotation}deg)`;
    minute.style.transform = `rotate(${min_rotation}deg)`;
    second.style.transform = `rotate(${sec_rotation}deg)`;

},1000)

