const searchInput = document.querySelector("#searchInput");

searchInput.addEventListener("keyup", (e) => {
	if (e.key == "Enter" && searchInput.value != "") {
		getData(searchInput.value);
	}
	if (searchInput.value == "") {
		waitMSG.classList.remove("activeWaitMsg");
	}
})

// fetch data through API

const waitMSG = document.querySelector("#waitMsg");


let getData = async (city) => {
	const apiKey = `bb105f2dcaa5742ddd3781e5d24b6667`;
	let apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
	waitMSG.classList.add("activeWaitMsg");
	let getFachedData = await fetch(apiUrl);
	let getResponceData = await getFachedData.json();
	document.querySelector("#box").style.display = 'block';
	return showData(getResponceData);
}

function showData(returnData) {
	console.log(returnData);
	let box = document.querySelector("#box");
	box.innerHTML = `
		<div class="box-header">
			<h1>Weather App</h1>
		</div>
		<div class="box-body">
			<img src="http://openweathermap.org/img/wn/${returnData.weather[0].icon}@2x.png">
			<h1>${returnData.main.temp}<sup>o</sup><span>C</span></h1>
			<span class="haze">${returnData.weather[0].main}</span>
		</div>
		<div class="box-bottom">
			<h2><span><i class="fas fa-map-marker-alt"></i></span> ${returnData.name}, ${returnData.sys.country}</h2>
		</div>
	`;
}
