
const subBtn = document.querySelector("#subBtn");
const inputName = document.querySelector(".input-name");
const infoBox = document.querySelector(".info-box");
const showNames = document.querySelectorAll("#showName");
const entName = document.querySelector("#entName");


subBtn.addEventListener("click", () => {
    infoBox.classList.add("activeInfo");
    inputName.classList.add("removeInput");
    for (let i = 0; i < showNames.length; i++) {
        showNames[i].innerHTML = `${entName.value}`;
    }
});


const startBtn = document.querySelector("#startBtn");
const queBox = document.querySelector(".que-box");
let optionList = document.querySelectorAll("#queList li");
const mainQue = document.querySelector("#mainQue");
const totleQue = document.querySelector("#totleQue");
const queNexts = document.querySelector("#queNext");
let inscreser = 0;
function inscreseQues() {
    inscreser++;
}

startBtn.addEventListener("click", () => {
    infoBox.classList.remove("activeInfo");
    queBox.classList.add("activeQue");
    timer(); // 

    // script for first question

    for (let i in optionList) {
        var forQuestion = () => {
            mainQue.innerHTML = `${questionsList[inscreser].numb}. ${questionsList[inscreser].question}`;
        }
        forQuestion(); // for question

        optionList[i].innerHTML = `${questionsList[inscreser].options[i]}`; // for option
    }

    let totleQuesCounter = () => {
        totleQue.innerHTML = `${questionsList[inscreser].numb} of ${questionsList.length}`;
    }
    totleQuesCounter(); // for tottle question count


    // script for change question
    
    queNexts.classList.add("closeQuesNext");

    queNexts.addEventListener("click", () => {
        inscreseQues();
        forQuestion();
        totleQuesCounter();
        timer(); // start Timer
        for (let i = 0; i < optionList.length; i++) {
            optionList[i].innerHTML = `${questionsList[inscreser].options[i]}`;
            optionList[i].classList.remove("bgRed");
            optionList[i].classList.remove("bgGreen");
            optionList[i].classList.remove("disable");
        }
        if (questionsList[inscreser].numb == questionsList.length) {
            queNexts.classList.add("removeInput");
            let finishBtn = document.querySelector("#finish");
            finishBtn.classList.add("activeFinishBtn")
            finishBtn.addEventListener("click", () => {
                let resultPage = document.querySelector(".result-page");
                resultPage.classList.add("resultPageActive");
                queBox.classList.remove("activeQue");

            })
        }
        queNexts.classList.add("closeQuesNext");
    });

})

// checking answer when user click options

for (let i = 0; i < optionList.length; i++) {

    optionList[i].addEventListener("click", () => {
        if (optionList[i].innerText == questionsList[inscreser].answer) {
            optionList[i].classList.add("bgGreen");
            optionList[i].innerHTML += `<span class="icons"><i class="fas fa-smile-beam"></i></span>`;
            correctAns();
        }
        else {
            optionList[i].classList.add("bgRed");
            optionList[i].innerHTML += `<span class="icons"><i class="fas fa-sad-cry"></i></span>`;

            for (let i = 0; i < optionList.length; i++) {
                if (optionList[i].innerText == questionsList[inscreser].answer) {
                    optionList[i].classList.add("bgGreen");
                    optionList[i].innerHTML += `<span class="icons"><i class="fas fa-smile-beam"></i></span>`;
                }
            }
        }

        // script for disable all option when user cliked

        for (let i = 0; i < optionList.length; i++) {
            optionList[i].classList.add("disable");
        }
        clrSetInt(); // clear Timer

        // script for show next btn when user cliked on answer

        queNexts.classList.remove("closeQuesNext");
    });
}


// script for timer & auto correct answer

let timerDiv = document.querySelector("#timer");
let setInt;

function timer() {
    let sec = 10;
    setInt = setInterval(() => {
        timerDiv.innerHTML = sec;
        --sec;

        // script for stop when sec is equal to 0

        if (sec < 0) {
            clrSetInt();
            queNexts.classList.remove("closeQuesNext");
            timerDiv.innerHTML = `Time out`;
            for (let i = 0; i < optionList.length; i++) {
                optionList[i].classList.add("disable");
            }

            for (let i = 0; i < optionList.length; i++) {
                if (optionList[i].innerText == questionsList[inscreser].answer) {
                    optionList[i].classList.add("bgGreen");
                    optionList[i].innerHTML += `<span class="icons"><i class="fas fa-smile-beam"></i></span>`;
                }
            }
        }
    }, 1000);
}
function clrSetInt() {
    clearInterval(setInt);
}


// script for result page

let comments = document.querySelector("#comments");
var correct = 0;
let sadEmoji = document.querySelector("#sadEmoji");
let congrat = document.querySelector("#Congrates");

// var passingMark = questionsList.length - correct;

function correctAns() {
    comments.innerHTML = `${correct++}`;

    if (correct > questionsList.length - correct) {
        comments.innerHTML = `We proud of you ${entName.value} Your've given correct answer ${correct} of ${questionsList.length}`;
        sadEmoji.innerHTML = `<i class="fas fa-award"></i>`;
        congrat.innerHTML = `Congratulation ${entName.value}`;
    }
    else {
        comments.innerHTML = `Oh bad ${entName.value} Your've given correct answer ${correct} of ${questionsList.length}`;
        sadEmoji.innerHTML = `<i class="fas fa-frown"></i>`;
        congrat.innerHTML = `Oh bad ${entName.value}`;
    }
}
